'use strict';

angular.module('mobileDemo')
  .controller('MainCtrl', function ($scope) {
  });
