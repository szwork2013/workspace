'use strict';

angular.module('mobileDemo')
  .controller('SettingCtrl', function ($scope) {
  });
