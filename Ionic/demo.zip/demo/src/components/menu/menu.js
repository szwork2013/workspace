'use strict';

angular.module('mobileDemo')
  .controller('MenuCtrl', function ($scope) {
  });
