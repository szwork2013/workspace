This project has been created in [generator-gulp-angular](https://github.com/Swiip/generator-gulp-angular) and [ionic](http://ionicframework.com/).

### Demo

[http://hkusu.github.io/ionic-website-demo/dist](http://hkusu.github.io/ionic-website-demo/dist)

### How to deploy to local environment

```
$ git clone https://github.com/hkusu/ionic-website-demo
$ cd ionic-website-demo
$ npm install
$ bower install
```

### License

MIT
